package com.personal.browser.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.personal.browser.R
import com.personal.browser.models.Bookmark

class BookmarkAdapter(
    private val bookmarks: MutableList<Bookmark>,
    private val onBookmarkClick: (Bookmark) -> Unit,
    private val onBookmarkDelete: (Bookmark) -> Unit
) : RecyclerView.Adapter<BookmarkAdapter.BookmarkViewHolder>() {

    inner class BookmarkViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView    = view.findViewById(R.id.bookmarkTitle)
        val url: TextView      = view.findViewById(R.id.bookmarkUrl)
        val delete: ImageButton = view.findViewById(R.id.bookmarkDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookmarkViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_bookmark, parent, false)
        return BookmarkViewHolder(view)
    }

    override fun onBindViewHolder(holder: BookmarkViewHolder, position: Int) {
        val bm = bookmarks[position]
        holder.title.text = bm.title
        holder.url.text   = bm.url
        holder.itemView.setOnClickListener { onBookmarkClick(bm) }
        holder.delete.setOnClickListener {
            bookmarks.removeAt(position)
            notifyItemRemoved(position)
            onBookmarkDelete(bm)
        }
    }

    override fun getItemCount() = bookmarks.size
}
