package com.personal.browser.models

import android.os.Bundle

data class Tab(
    var url: String = "about:blank",
    var title: String = "New Tab",
    val isIncognito: Boolean = false,
    var savedState: Bundle? = null
)

data class Bookmark(
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class HistoryEntry(
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis()
)
