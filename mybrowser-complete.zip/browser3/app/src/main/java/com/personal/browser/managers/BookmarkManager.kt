package com.personal.browser.managers

import android.content.Context
import com.personal.browser.models.Bookmark
import org.json.JSONArray
import org.json.JSONObject

class BookmarkManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("bookmarks", Context.MODE_PRIVATE)
    private val KEY = "bookmark_list"

    fun getAll(): List<Bookmark> {
        val json = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            Bookmark(
                title     = obj.getString("title"),
                url       = obj.getString("url"),
                timestamp = obj.getLong("timestamp")
            )
        }.sortedByDescending { it.timestamp }
    }

    fun add(title: String, url: String) {
        val list = getAll().toMutableList()
        list.removeAll { it.url == url } // avoid duplicates
        list.add(0, Bookmark(title, url))
        save(list)
    }

    fun remove(url: String) {
        val list = getAll().toMutableList()
        list.removeAll { it.url == url }
        save(list)
    }

    private fun save(list: List<Bookmark>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("title",     it.title)
                put("url",       it.url)
                put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
