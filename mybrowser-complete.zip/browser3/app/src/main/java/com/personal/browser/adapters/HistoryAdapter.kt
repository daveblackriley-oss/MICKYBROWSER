package com.personal.browser.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.personal.browser.R
import com.personal.browser.models.HistoryEntry
import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter(
    private val entries: MutableList<HistoryEntry>,
    private val onEntryClick: (HistoryEntry) -> Unit,
    private val onEntryDelete: (HistoryEntry) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    inner class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView     = view.findViewById(R.id.historyTitle)
        val url: TextView       = view.findViewById(R.id.historyUrl)
        val time: TextView      = view.findViewById(R.id.historyTime)
        val delete: ImageButton = view.findViewById(R.id.historyDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val entry = entries[position]
        holder.title.text = entry.title.ifBlank { entry.url }
        holder.url.text   = entry.url
        holder.time.text  = formatTime(entry.timestamp)
        holder.itemView.setOnClickListener { onEntryClick(entry) }
        holder.delete.setOnClickListener {
            entries.removeAt(position)
            notifyItemRemoved(position)
            onEntryDelete(entry)
        }
    }

    override fun getItemCount() = entries.size

    private fun formatTime(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        return when {
            diff < 60_000 -> "Just now"
            diff < 3_600_000 -> "${diff / 60_000}m ago"
            diff < 86_400_000 -> "${diff / 3_600_000}h ago"
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(timestamp))
        }
    }
}
