package com.personal.browser.managers

import android.content.Context
import com.personal.browser.models.HistoryEntry
import org.json.JSONArray
import org.json.JSONObject

class HistoryManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("history", Context.MODE_PRIVATE)
    private val KEY = "history_list"
    private val MAX_ENTRIES = 500

    fun getAll(): List<HistoryEntry> {
        val json = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            HistoryEntry(
                title     = obj.getString("title"),
                url       = obj.getString("url"),
                timestamp = obj.getLong("timestamp")
            )
        }.sortedByDescending { it.timestamp }
    }

    fun add(title: String, url: String) {
        if (url.isBlank() || url == "about:blank") return
        val list = getAll().toMutableList()
        // Remove duplicate URL if exists
        list.removeAll { it.url == url }
        list.add(0, HistoryEntry(title.ifBlank { url }, url))
        // Trim to max
        val trimmed = if (list.size > MAX_ENTRIES) list.subList(0, MAX_ENTRIES) else list
        save(trimmed)
    }

    fun remove(url: String) {
        val list = getAll().toMutableList()
        list.removeAll { it.url == url }
        save(list)
    }

    fun clearAll() {
        prefs.edit().remove(KEY).apply()
    }

    private fun save(list: List<HistoryEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("title",     it.title)
                put("url",       it.url)
                put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
