package com.personal.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.view.*
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.personal.browser.adapters.BookmarkAdapter
import com.personal.browser.adapters.HistoryAdapter
import com.personal.browser.adapters.TabAdapter
import com.personal.browser.managers.*
import com.personal.browser.models.Tab

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnTabs: ImageButton
    private lateinit var btnMenu: ImageButton
    private lateinit var tabCountBadge: TextView
    private lateinit var incognitoBadge: View

    private val tabs = mutableListOf<Tab>()
    private var currentTabIndex = 0
    private var isIncognito = false

    private lateinit var bookmarkManager: BookmarkManager
    private lateinit var historyManager: HistoryManager
    private lateinit var adBlocker: AdBlocker
    private lateinit var downloadHandler: DownloadHandler
    private lateinit var startPageManager: StartPageManager

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bookmarkManager  = BookmarkManager(this)
        historyManager   = HistoryManager(this)
        adBlocker        = AdBlocker(this)
        downloadHandler  = DownloadHandler(this)
        startPageManager = StartPageManager(this)

        bindViews()
        openNewTab()
        setupButtons()
    }

    private fun bindViews() {
        webView        = findViewById(R.id.webView)
        urlBar         = findViewById(R.id.urlBar)
        progressBar    = findViewById(R.id.progressBar)
        swipeRefresh   = findViewById(R.id.swipeRefresh)
        btnBack        = findViewById(R.id.btnBack)
        btnForward     = findViewById(R.id.btnForward)
        btnRefresh     = findViewById(R.id.btnRefresh)
        btnHome        = findViewById(R.id.btnHome)
        btnTabs        = findViewById(R.id.btnTabs)
        btnMenu        = findViewById(R.id.btnMenu)
        tabCountBadge  = findViewById(R.id.tabCountBadge)
        incognitoBadge = findViewById(R.id.incognitoBadge)
    }

    // ─── START PAGE ───────────────────────────────────────────────────────────

    private fun loadStartPage() {
        val customUrl = startPageManager.customUrl
        if (startPageManager.useCustomUrl && customUrl.isNotBlank()) {
            webView.loadUrl(customUrl)
        } else {
            val bookmarks = bookmarkManager.getAll().map { it.title to it.url }
            val html = startPageManager.getStartPageHtml(bookmarks)
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
    }

    // ─── TAB MANAGEMENT ───────────────────────────────────────────────────────

    fun openNewTab(incognito: Boolean = isIncognito) {
        val tab = Tab(url = "about:blank", isIncognito = incognito)
        tabs.add(tab)
        currentTabIndex = tabs.size - 1
        setupWebView(incognito)
        loadStartPage()
        updateTabBadge()
        updateIncognitoBadge()
    }

    fun switchToTab(index: Int) {
        if (index < 0 || index >= tabs.size) return
        val bundle = Bundle()
        webView.saveState(bundle)
        tabs[currentTabIndex].savedState = bundle
        tabs[currentTabIndex].url   = webView.url ?: tabs[currentTabIndex].url
        tabs[currentTabIndex].title = webView.title ?: tabs[currentTabIndex].title

        currentTabIndex = index
        val tab = tabs[index]
        isIncognito = tab.isIncognito
        setupWebView(tab.isIncognito)
        if (tab.savedState != null) webView.restoreState(tab.savedState!!)
        else loadStartPage()

        updateTabBadge()
        updateIncognitoBadge()
    }

    fun closeTab(index: Int) {
        if (tabs.size == 1) {
            tabs[0] = Tab()
            currentTabIndex = 0
            setupWebView(false)
            loadStartPage()
            updateTabBadge()
            return
        }
        tabs.removeAt(index)
        currentTabIndex = (index - 1).coerceAtLeast(0)
        switchToTab(currentTabIndex)
    }

    private fun updateTabBadge()     { tabCountBadge.text = tabs.size.toString() }
    private fun updateIncognitoBadge() {
        incognitoBadge.visibility = if (isIncognito) View.VISIBLE else View.GONE
    }

    // ─── WEBVIEW SETUP ────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(incognito: Boolean = false) {
        CookieManager.getInstance().setAcceptCookie(!incognito)
        webView.settings.apply {
            javaScriptEnabled        = true
            domStorageEnabled        = !incognito
            loadsImagesAutomatically = true
            useWideViewPort          = true
            loadWithOverviewMode     = true
            builtInZoomControls      = true
            displayZoomControls      = false
            setSupportZoom(true)
            mixedContentMode         = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
            if (incognito) { saveFormData = false }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                urlBar.setText(url)
                progressBar.visibility = View.VISIBLE
                updateNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String) {
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false
                urlBar.setText(if (url == "about:blank") "" else url)
                tabs.getOrNull(currentTabIndex)?.apply {
                    this.url   = url
                    this.title = view.title ?: url
                }
                if (!incognito && url != "about:blank" && !url.startsWith("data:")) {
                    historyManager.add(view.title ?: url, url)
                }
                updateNavButtons()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return when {
                    url.startsWith("http") || url.startsWith("https") -> { view.loadUrl(url); true }
                    url.startsWith("tel:") || url.startsWith("mailto:") -> {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); true
                    }
                    else -> false
                }
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return if (adBlocker.isEnabled && adBlocker.shouldBlock(request.url.host ?: ""))
                    adBlocker.emptyResponse() else null
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress == 100) progressBar.visibility = View.GONE
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            downloadHandler.startDownload(url, userAgent, contentDisposition, mimeType)
        }

        swipeRefresh.setOnRefreshListener { webView.reload() }
        swipeRefresh.setColorSchemeResources(R.color.accent)

        urlBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                loadUrlFromBar(); true
            } else false
        }
    }

    private fun loadUrlFromBar() {
        val input = urlBar.text.toString().trim()
        val url = when {
            input.isEmpty() -> { loadStartPage(); return }
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${Uri.encode(input)}"
        }
        webView.loadUrl(url)
        urlBar.clearFocus()
    }

    private fun updateNavButtons() {
        btnBack.alpha    = if (webView.canGoBack()) 1.0f else 0.4f
        btnForward.alpha = if (webView.canGoForward()) 1.0f else 0.4f
    }

    // ─── BUTTONS ──────────────────────────────────────────────────────────────

    private fun setupButtons() {
        btnBack.setOnClickListener    { if (webView.canGoBack()) webView.goBack() }
        btnForward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener { webView.reload() }
        btnHome.setOnClickListener    { loadStartPage() }
        btnTabs.setOnClickListener    { showTabsSheet() }
        btnMenu.setOnClickListener    { showMenuSheet() }
    }

    // ─── TABS SHEET ───────────────────────────────────────────────────────────

    private fun showTabsSheet() {
        val sheet = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val view  = layoutInflater.inflate(R.layout.sheet_tabs, null)
        sheet.setContentView(view)
        val rv       = view.findViewById<RecyclerView>(R.id.rvTabs)
        val btnNew   = view.findViewById<Button>(R.id.btnNewTab)
        val btnIncog = view.findViewById<Button>(R.id.btnIncognitoTab)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = TabAdapter(tabs, currentTabIndex,
            onTabClick  = { idx -> switchToTab(idx); sheet.dismiss() },
            onTabClose  = { idx -> closeTab(idx); rv.adapter?.notifyDataSetChanged() }
        )
        btnNew.setOnClickListener   { openNewTab(false); sheet.dismiss() }
        btnIncog.setOnClickListener { openNewTab(true);  sheet.dismiss() }
        sheet.show()
    }

    // ─── MENU SHEET ───────────────────────────────────────────────────────────

    private fun showMenuSheet() {
        val sheet = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val view  = layoutInflater.inflate(R.layout.sheet_menu, null)
        sheet.setContentView(view)

        val btnBookmark   = view.findViewById<LinearLayout>(R.id.menuBookmark)
        val btnBookmarks  = view.findViewById<LinearLayout>(R.id.menuBookmarks)
        val btnHistory    = view.findViewById<LinearLayout>(R.id.menuHistory)
        val btnAdBlock    = view.findViewById<LinearLayout>(R.id.menuAdBlock)
        val adBlockStatus = view.findViewById<TextView>(R.id.adBlockStatus)
        val btnShare      = view.findViewById<LinearLayout>(R.id.menuShare)
        val btnDesktop    = view.findViewById<LinearLayout>(R.id.menuDesktop)
        val btnStartPage  = view.findViewById<LinearLayout>(R.id.menuStartPage)

        adBlockStatus.text = if (adBlocker.isEnabled) "ON" else "OFF"
        adBlockStatus.setTextColor(getColor(if (adBlocker.isEnabled) R.color.green else R.color.text_hint))

        btnBookmark.setOnClickListener {
            val url = webView.url ?: return@setOnClickListener
            bookmarkManager.add(webView.title ?: url, url)
            Toast.makeText(this, "Bookmarked!", Toast.LENGTH_SHORT).show()
            sheet.dismiss()
        }
        btnBookmarks.setOnClickListener { sheet.dismiss(); showBookmarksSheet() }
        btnHistory.setOnClickListener   { sheet.dismiss(); showHistorySheet() }
        btnAdBlock.setOnClickListener {
            adBlocker.isEnabled = !adBlocker.isEnabled
            adBlockStatus.text = if (adBlocker.isEnabled) "ON" else "OFF"
            adBlockStatus.setTextColor(getColor(if (adBlocker.isEnabled) R.color.green else R.color.text_hint))
        }
        btnShare.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, webView.url) }
            startActivity(Intent.createChooser(intent, "Share URL"))
            sheet.dismiss()
        }
        btnDesktop.setOnClickListener {
            val ua = if (webView.settings.userAgentString.contains("Mobile"))
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
            else WebSettings.getDefaultUserAgent(this)
            webView.settings.userAgentString = ua
            webView.reload(); sheet.dismiss()
        }
        btnStartPage.setOnClickListener { sheet.dismiss(); showStartPageSheet() }
        sheet.show()
    }

    // ─── BOOKMARKS SHEET ──────────────────────────────────────────────────────

    private fun showBookmarksSheet() {
        val sheet = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val view  = layoutInflater.inflate(R.layout.sheet_bookmarks, null)
        sheet.setContentView(view)
        val rv    = view.findViewById<RecyclerView>(R.id.rvBookmarks)
        val empty = view.findViewById<TextView>(R.id.emptyBookmarks)
        val list  = bookmarkManager.getAll().toMutableList()
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = BookmarkAdapter(list,
            onBookmarkClick   = { bm -> webView.loadUrl(bm.url); sheet.dismiss() },
            onBookmarkDelete  = { bm -> bookmarkManager.remove(bm.url) }
        )
        sheet.show()
    }

    // ─── HISTORY SHEET ────────────────────────────────────────────────────────

    private fun showHistorySheet() {
        val sheet = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val view  = layoutInflater.inflate(R.layout.sheet_history, null)
        sheet.setContentView(view)
        val rv       = view.findViewById<RecyclerView>(R.id.rvHistory)
        val empty    = view.findViewById<TextView>(R.id.emptyHistory)
        val btnClear = view.findViewById<Button>(R.id.btnClearHistory)
        val list     = historyManager.getAll().toMutableList()
        empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = HistoryAdapter(list,
            onEntryClick   = { entry -> webView.loadUrl(entry.url); sheet.dismiss() },
            onEntryDelete  = { entry -> historyManager.remove(entry.url) }
        )
        btnClear.setOnClickListener {
            historyManager.clearAll()
            list.clear()
            rv.adapter?.notifyDataSetChanged()
            empty.visibility = View.VISIBLE
        }
        sheet.show()
    }

    // ─── START PAGE SHEET ─────────────────────────────────────────────────────

    private fun showStartPageSheet() {
        val sheet = BottomSheetDialog(this, R.style.BottomSheetTheme)
        val view  = layoutInflater.inflate(R.layout.sheet_startpage, null)
        sheet.setContentView(view)

        val inputGreeting  = view.findViewById<EditText>(R.id.inputGreeting)
        val inputColor     = view.findViewById<EditText>(R.id.inputColor)
        val colorPreview   = view.findViewById<View>(R.id.colorPreview)
        val inputCustomUrl = view.findViewById<EditText>(R.id.inputCustomUrl)
        val btnSave        = view.findViewById<Button>(R.id.btnSaveStartPage)

        inputGreeting.setText(startPageManager.greeting)
        inputColor.setText(startPageManager.wallpaperColor)
        inputCustomUrl.setText(startPageManager.customUrl)

        fun updatePreview() {
            try { colorPreview.setBackgroundColor(Color.parseColor(inputColor.text.toString())) } catch (_: Exception) {}
        }
        updatePreview()
        inputColor.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = updatePreview()
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })

        val swatches = listOf(
            view.findViewById<View>(R.id.swatch1) to "#0F1117",
            view.findViewById<View>(R.id.swatch2) to "#0D1B2A",
            view.findViewById<View>(R.id.swatch3) to "#1A0A2E",
            view.findViewById<View>(R.id.swatch4) to "#0A1F0A",
            view.findViewById<View>(R.id.swatch5) to "#1A0A0A",
            view.findViewById<View>(R.id.swatch6) to "#101820"
        )
        swatches.forEach { (v, hex) ->
            v.setOnClickListener { inputColor.setText(hex); updatePreview() }
        }

        btnSave.setOnClickListener {
            startPageManager.greeting      = inputGreeting.text.toString().ifBlank { "Hello!" }
            startPageManager.wallpaperColor = inputColor.text.toString().ifBlank { "#0F1117" }
            val customUrl = inputCustomUrl.text.toString().trim()
            startPageManager.customUrl    = customUrl
            startPageManager.useCustomUrl = customUrl.isNotBlank()
            Toast.makeText(this, "Start page saved!", Toast.LENGTH_SHORT).show()
            sheet.dismiss()
        }
        sheet.show()
    }

    // ─── LIFECYCLE ────────────────────────────────────────────────────────────

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        if (isIncognito) {
            WebStorage.getInstance().deleteAllData()
            CookieManager.getInstance().removeAllCookies(null)
        }
    }
}
